package com.csljc;

class ListNode {
    int val;
    ListNode next;
    ListNode(int x) {
        val = x;
    }
}
/**
 * @author ����
 */
 
public class Solution {
    public ListNode sortList(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }
        //����ָ�����м���,midΪ��һ��ĩβ
        ListNode mid = null, slow = head, fast = head;
        while (fast != null && fast.next != null) {
            mid = slow;
            slow = slow.next;
            fast = fast.next.next;
        }
        mid.next = null;
        //���߷ֱ�����
        ListNode list1 = sortList(head);
        ListNode list2 = sortList(slow);
        //�ϲ�
        return merge(list1, list2);
    }
 
    //�ϲ�
    public ListNode merge(ListNode list1, ListNode list2) {
        ListNode res = new ListNode(0), p = res;
        while (list1 != null && list2 != null) {
            if (list1.val < list2.val) {
                res.val = list1.val;
                p.next = list1;
                list1 = list1.next;
            } else {
                res.val = list2.val;
                p.next = list2;
                list2 = list2.next;
            }
            p = p.next;
        }
 
        if (list1 != null) {
            p.next = list1;
        }
        if (list2 != null) {
            p.next = list2;
        }
        return res.next;
    }
 
}
	
