package com.csljc;

import static org.junit.Assert.*;

import org.junit.Test;

/**
 * @author ����
 */
public class SolutionTest {

	@Test
	public void testSortList() {
		ListNode a = new ListNode(6);
        a.next = new ListNode(2);
        a.next.next = new ListNode(8);
        a.next.next.next = new ListNode(3);
        a.next.next.next.next = new ListNode(5);
 
        Solution sol = new Solution();
        ListNode c = sol.sortList(a);
        assertEquals(2,c.val);
        assertEquals(3,c.next.val);
        assertEquals(5,c.next.next.val);
        assertEquals(6,c.next.next.next.val);
        assertEquals(8,c.next.next.next.next.val);
	}

	@Test
	public void testMerge() {
		ListNode a = new ListNode(-1);
        a.next = new ListNode(2);
        a.next.next = new ListNode(8);
        
		ListNode b = new ListNode(0);
        b.next = new ListNode(4);
        b.next.next = new ListNode(9);
        
        ListNode c = new Solution().merge(a,b);
        
        assertEquals(-1,c.val);
        assertEquals(0,c.next.val);
        assertEquals(2,c.next.next.val);
        assertEquals(4,c.next.next.next.val);
        assertEquals(8,c.next.next.next.next.val);
        assertEquals(9,c.next.next.next.next.next.val);
	}

}
