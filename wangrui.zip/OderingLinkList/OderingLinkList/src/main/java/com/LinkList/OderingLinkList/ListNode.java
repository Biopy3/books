package com.LinkList.OderingLinkList;

public class ListNode {
	int val;
	ListNode next;
	ListNode(int x) {
		val=x;
	};
}//ListNode end

class Solution {
	public ListNode sortList( ListNode head) {
		if (head == null || head.next == null) {
            return head;
        }
        //split to identical two partitions
        ListNode cur = null, slow = head, fast = head;
        while (fast != null && fast.next != null) {//if node's index is odd, the left node put on the second partition
            cur = slow;
            slow = slow.next;
            fast = fast.next.next;
        }
        cur.next = null;
        //every partition should sort then merge with order
        ListNode l1 = sortList(head);
        ListNode l2 = sortList(slow);
        
        return merge(l1, l2);
    }//sortList
 
    public ListNode merge(ListNode l1, ListNode l2) {
        ListNode res = new ListNode(0), p = res;
        while (l1 != null && l2 != null) {
            if (l1.val < l2.val) {
                res.val = l1.val;
                p.next = l1;//don't forget!
                l1 = l1.next;
            } else {
                res.val = l2.val;
                p.next = l2;
                l2 = l2.next;
            }
            p = p.next;
        }//while
 
        if (l1 != null) {
            p.next = l1;
        }
        if (l2 != null) {
//            p.next = l2.next;can't be p.next = l2.next
            p.next = l2;
        }
        return res.next;/* ListNode res = new ListNode(0)Because the first node is 0,,it's res.next, not res*/
    }//merge
}