package com.LinkList.OderingLinkList;

import java.util.Scanner;

public class App 
{
    public static void main( String[] args )
    {
    	System.out.println("Please put in a link list, for example:\n"
    			+ "\tRight: -1->-07->0 (zero is valid in the front of integer)\n"
    			+ "\tWrong: +1->-07->0 (for positive integer without plus prefix)\n>");
    	Scanner in = new Scanner(System.in);
    	String regx = "^-?[0-9]*(->-?[0-9]*)*";
    	String inString = in.next();
    	in.close();
    	boolean match = inString.matches(regx);
    	if( !match) {
    		System.out.println("The input format is invalid! Exit!");
    	}
    	else {
//    		System.out.println(inString);
	    	String[] inListIntegerString = inString.split("->");
	    	ListNode aListNode = new ListNode(Integer.valueOf(inListIntegerString[0]));
	    	ListNode tempListNode = aListNode;
	    	for( int i = 1; i < inListIntegerString.length; i++) {
//	    		System.out.println(Integer.valueOf(inListIntegerString[i]));
	    		tempListNode.next = new ListNode(Integer.valueOf(inListIntegerString[i]));
	    		tempListNode = tempListNode.next;
	    	}
	    	
	    	/*for ordering link list*/
	    	Solution solution = new Solution();
	        ListNode orderedList = solution.sortList(aListNode);
	        
	        /*for outputting ordered LinkedList*/
	        System.out.print("The ordered results: " + orderedList.val);
	        orderedList = orderedList.next;
	        while(orderedList != null) {
	        	System.out.print("->" + orderedList.val);
	        	orderedList = orderedList.next;
	        }
    	}
        
    }
}
